import scrapy

class TmdbSpider(scrapy.Spider):
    name = 'tmdb_spider'
    
    start_urls = ['https://www.themoviedb.org/movie/455207-crazy-rich-asians']

    def parse(self, response):
        '''
        Assumption: 'start_urls' is the landing page of the movie in interest
        Purpose: Navigate from the main movie page to the casting information page
        Output: No output returned, gets casting page url and yields to 'parse_full_credits' method to look at the actors
        '''
        # assumes we start at the main page of the movie of interest, then navigate to the cast page
        next_page_cast = response.url + "/cast"
        yield scrapy.Request(next_page_cast, callback=self.parse_full_credits)

    def parse_full_credits(self, response):
        '''
        Assumption: url is on the cast page of the movie in interest
        Purpose: Navigate from the cast page to the individual actors' pages
        Output: No output returned, gets individual actors' page urls and yields to 'parse_actor_page' method to look at the actor's page
        '''
        # assumes we are on Cast Page: get pages for all the actors casted in this movie
        actor_end_urls = response.css('div.info a::attr(href)').getall()

        for actor in actor_end_urls: # for each listed, append url to the website link
            actor_url = 'https://www.themoviedb.org' + actor
            yield scrapy.Request(actor_url, callback=self.parse_actor_page)

    def parse_actor_page(self, response):
        '''
        Assumption: url is at a specific actor's page
        Purpose: Collect all the movies and TV shows an actor has worked on
        Output: Returns a dictionary of the movies and TV shows that the actor has been in
        '''
        # assumes we are on the specific actor's page: looks at the works this actor has been in
        # returns dictionary of Extract actor name and their work (movie or TV show)
        actor_name = response.css('div.title a::text').get()
        
        movie_TV_names = response.css('td.role a.tooltip bdi::text').getall()
        
        for work in movie_TV_names:
            yield {"actor": actor_name, "movie_or_TV_name": work}

